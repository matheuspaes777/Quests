import { View,Text } from "react-native";
import casca from "../css/estilo";
export default function Perguntas2(){
    return(
        <View style={casca.container}>
            <Text>Pergunta2</Text>
        </View>
    );
}