import { View,Text } from "react-native";
import casca from "../css/estilo";
export default function Perguntas1(){
    return(
        <View style={casca.container}>
            <Text>Pergunta1</Text>
        </View>
    );
}