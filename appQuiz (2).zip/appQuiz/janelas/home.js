import { View,Text,Button } from "react-native";
import casca from "../css/estilo";
export default function Home({navigation}){
    return(
        <View style={casca.container}>
            <Text>Home</Text>
            <Button title="Pergunta1"onPress={()=>navigation.navigate('PG1')}/>
            <Button title="Pergunta2"onPress={()=>navigation.navigate('PG2')}/>
        </View>
    );
}