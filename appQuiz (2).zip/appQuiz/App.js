import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import Home from './janelas/home';
import Perguntas1 from './janelas/pergunta1';
import Perguntas2 from './janelas/pergunta2';

const Stack = createNativeStackNavigator();

export default function App(){
  return(
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home}/>
        <Stack.Screen name="PG1" component={Perguntas1}/>
        <Stack.Screen name="PG2" component={Perguntas2}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}